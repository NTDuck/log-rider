# LogRider report v14

## Canonical build

The canonical compiler is **pdfLaTeX**.

```bash
pdflatex -interaction=nonstopmode -halt-on-error main-v14.tex
```

This package is derived from `logrider_v13.zip` and replaces every v13 evidence marker with executed v14 benchmark content or an explicit measured failure.

## Project structure

- `main-v14.tex`: report source.
- `results-v14.tex`: generated benchmark macros.
- `evidence/selected-run-manifest.json`: manifest of selected v14 runs.
- `evidence/benchmarks/v14-runner.mjs`: benchmark runner used for v14.
- `evidence/benchmarks/v14-targets.env`: predeclared local benchmark targets.
- `evidence/benchmarks/results/`: retained raw artifacts for selected runs.
- `assets/diagrams/src/`: Mermaid and PlantUML source recreations.
- `assets/figures/`: vector figures referenced by the report.

## Evidence summary

V14 executed 12 selected scenarios. Smoke, burst, ramp, API query and WebSocket connection passed. Baseline and stress failed the durable-drain criterion. Alert aggregation failed because the alert-worker replicas crash with a SyntaxError. WebSocket RBAC failed with one unauthorized out-of-scope event. Classifier quality failed against the local benchmark taxonomy. gRPC auth failed because an unauthenticated request succeeded.
