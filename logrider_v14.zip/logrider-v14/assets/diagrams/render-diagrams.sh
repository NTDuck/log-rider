#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
SRC="$ROOT/diagrams/src"
GEN="$ROOT/diagrams/generated"
FIG="$ROOT/figures"

need() {
  command -v "$1" >/dev/null 2>&1 || {
    echo "missing required tool: $1" >&2
    exit 127
  }
}

need npx
need java
need rsvg-convert

mkdir -p "$GEN" "$FIG"

for name in fig-log-lifecycle fig-alert-current fig-telegram-current; do
  npx mmdc \
    --input "$SRC/$name.mmd" \
    --output "$GEN/$name-mermaid.svg" \
    --configFile "$ROOT/diagrams/mermaid-config.json" \
    --backgroundColor transparent

  java -jar "${PLANTUML_JAR:-tools/plantuml.jar}" \
    -tsvg \
    -o ../generated \
    "$SRC/$name.puml"

  rsvg-convert -f pdf \
    -o "$FIG/$name.pdf" \
    "$GEN/$name-mermaid.svg"
done
